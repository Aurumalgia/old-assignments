package ss;
/*
So, I have 2 methods of thought here, and they're shown in the stack structure. I think that's all I have to do, right,
with the rest of them? I already have DynamicList and DynamicArray in the linear package, so I'll be making new classes
that extend the list and implement the interface, and just return that class. Unless I'm supposed to do something else?

Thank You

Kha Pham

 */






/*
 * SSFactory -- Specialized Structure Factory
 *
 * NOTE WELL -- instructor will help you code this one and even
 * 				code for you if you like (when your classes are ready)
 *				Only purpose of the factory is to give coder "creative freedom"
 *				for this challenge.
 *
 * Replace each "return null;" with your code
 *
 * Purpose is to provide a public gateway for
 * construction of specialized structures.
 *
 * By using this one gateway, everything behind it
 * (specialized structure implementation) is all
 * coder's choice.
 *
 * SEE method below "newFoo" and "newLinkedStack" for examples
 * of how-to do these methods
 *
 * */

import linear.DynamicArray;
import linear.LinkedList;
import linear.StructureIterator;

public class StructureFactory {

	//---------------------------------------------------------
	//This first one is just to demo what we mean by
	//generating an object from the factory

	public static <T> Foo<T> newFoo() {
		//Generate and return a new Foo
		//1-2-3 (construct-initialize-return)

		// #1 -- Construct a Foo
		Foo<T> foo = new Foo<T>();

		/* #2 -- Send zero, one or more messages to the new
		  		object here (coder's choice). Whatever makes sense. */
		foo.pleaseBeNice();

		// #3 -- Return the new object
		return foo;
	}

	//---------------------------------------------------------
	//Generate Stacks (one linked, one arrayed)

	public static <T> StackStructure<T> newLinkedStack() {
		/*Do the 1-2-3 here (see "newFoo" at top of this file for example)
		Note: we have to make sure we are returning a stack that has linked structure
		Let's say we have class "MyStack"/
		Then this entire method would be something like:

			MyStack<T> struc = new MyStack<>();
			struc.sendMethodHereIfDesired();
			return struc;
		*/
		//YOUR CODE HERE (replace "return null;" with your code (per steps 1-2-3 above)
		return (StackStructure<T>) new linkedStack<T>();
	}

	public static <T> StackStructure<T> newArrayedStack() {
		//See comments in "newLinkedStack" above
		//Note that we need to return an arrayed structure here
		//YOUR CODE HERE (replace "return null;" with your code (per steps 1-2-3 above)

		class stackArray extends DynamicArray implements StackStructure{
			@Override
			public void push(Object newElem) {
				addFirst(newElem);
			}

			@Override
			public Object pop() {
				return removeFirst();
			}

			@Override
			public Object peek() {
				return first();
			}
		}



		return null;
	}

	//---------------------------------------------------------
	//Generate Queues (one linked, one arrayed)

	public static <T> QueueStructure<T> newLinkedQueue() {
		//See comments in "newLinkedStack" above
		//Note that we need to return an arrayed structure here
		//YOUR CODE HERE (replace "return null;" with your code (per steps 1-2-3 above)
		return null;
	}

	public static <T> QueueStructure<T> newArrayedQueue() {
		//See comments in "newLinkedStack" above
		//Note that we need to return a linked structure here
		//YOUR CODE HERE (replace "return null;" with your code (per steps 1-2-3 above)
		return null;
	}

	//---------------------------------------------------------
	//Generate Deques (one linked, one arrayed)

	public static <T> DequeStructure<T> newLinkedDeque() {
		//See comments in "newLinkedStack" above
		//Note that we need to return an arrayed structure here
		//YOUR CODE HERE (replace "return null;" with your code (per steps 1-2-3 above)
		return null;
	}

	public static <T> DequeStructure<T> newArrayedDeque() {
		//See comments in "newLinkedStack" above
		//Note that we need to return a linked structure here
		//YOUR CODE HERE (replace "return null;" with your code (per steps 1-2-3 above)
		return null;
	}

	//---------------------------------------------------------
	//Generate Bags (one linked, one arrayed)

	public static <T> BagStructure<T> newLinkedBag() {
		//See comments in "newLinkedStack" above
		//Note that we need to return a linked structure here
		//YOUR CODE HERE (replace "return null;" with your code (per steps 1-2-3 above)
		return null;
	}

	public static <T> BagStructure<T> newArrayedBag() {
		//See comments in "newLinkedStack" above
		//Note that we need to return an arrayed structure here
		//YOUR CODE HERE (replace "return null;" with your code (per steps 1-2-3 above)
		return null;
	}

	//------------------------------------------------------------------
	//NOT USED BELOW

	//Class "Foo" is dummy class just to help with example "newFoo"
	static class Foo<T> {
		public void pleaseBeNice() {}
	}

	static class linkedStack<T> extends LinkedList implements StackStructure {
		@Override
		public void push(Object newElem) {
			addFirst(newElem);
		}

		@Override
		public Object pop() {
			return removeFirst();
		}

		@Override
		public Object peek() {
			return first();
		}

		@Override
		public StructureIterator toIterator() {
			return null;
		}
	}

}













