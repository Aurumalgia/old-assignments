package ss;

import linear.StructureIterator;

import java.util.ArrayList;

public interface DequeStructure<T> {
    public void addFirst(T newElem);
    public void addLast(T newElem);
    public T removeFirst();
    public T removeLast();
    public T first();
    public T last();

    public boolean isEmpty();
    public int size();
    public void clear();
    public ArrayList toJavaList();
    public StructureIterator toIterator();

    public void add(T newElem);
}
