package ss;

import linear.StructureIterator;

import java.util.ArrayList;

public interface BagStructure<T> {
    public void add(T newElem);
    public void any();
    public T remove(T searchElem);
    public boolean contains(T searchElem);
    public void clear();

    public boolean isEmpty();
    public int size();
    public ArrayList toJavaList();
    public StructureIterator<T> toIterator();
}
