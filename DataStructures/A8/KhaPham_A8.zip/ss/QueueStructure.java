package ss;

import linear.StructureIterator;

import java.util.ArrayList;

public interface QueueStructure<T> {
    public void enqueue(T newElem);
    public T dequeue();
    public T peek();

    public boolean isEmpty();
    public int size();
    public void clear();
    public ArrayList toJavaArray();
    public StructureIterator toIterator();

    public T add(T newElem);




}
