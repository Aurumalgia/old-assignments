package linear;

import java.util.ArrayList;
import java.util.List;

public class LinkedList implements DynamicList {
    Node firstNode;
    Node lastNode;
    int size = 0;
    public LinkedList(){

    }





    @Override
    public int size() {
        return size;
    }

    @Override
    public boolean isEmpty() {
        return size == 0;
    }

    @Override
    public Object get(int index) {
        Node currentNode = firstNode;
        for(int i = 0; i < index; i++){
            currentNode = currentNode.getNextNode();
        }
        return currentNode.getCurrentObject();
    }

    @Override
    public DynamicList subList(int start, int stop) {
        Node currentNode = firstNode;
        LinkedList l = new LinkedList();
        for(int i = 0; i < start; i++){
            currentNode =  currentNode.getNextNode();
        }
        for(int j = start; j <= stop; j++){
            l.add(currentNode.getCurrentObject());
            currentNode = currentNode.getNextNode();
        }
        return l;
    }

    @Override
    public Object first() {
        return firstNode.getCurrentObject();
    }

    @Override
    public Object last() {
        return lastNode.getCurrentObject();
    }

    @Override
    public boolean contains(Object searchElement) {
        boolean containsElement = false;
        Node currentNode = firstNode;
        while(!containsElement && currentNode != null){
            if (currentNode.getCurrentObject() == searchElement){
                containsElement = true;
            }
            else{
                currentNode = currentNode.getNextNode();
            }
        }
        return containsElement;
    }

    @Override
    public void addFirst(Object newData) {
        if (size == 0){
            initialNode(newData);
        }
        else{
            firstNode.setPreviousNode(new Node(newData, firstNode, null));
            firstNode = firstNode.getPreviousNode();
            size++;
            if (size == 2){
                lastNode = firstNode.getNextNode();
            }
        }

    }

    @Override
    public void addLast(Object newData) {
        if (size == 0){
            initialNode(newData);
        }
        else {
            lastNode.setNextNode(new Node(newData, null, lastNode));
            lastNode = lastNode.getNextNode();
            size++;
        }
    }

    @Override
    public void add(Object newData) {
        addLast(newData);
    }

    @Override
    public void clear() {
        while(firstNode != lastNode){
            removeFirst();
        }
        firstNode.delete();
    }

    @Override
    public Object remove(Object data) {
        boolean containsElement = false;
        Node currentNode = firstNode;
        while(!containsElement && currentNode != null){
            if (currentNode.getCurrentObject() == data){
                containsElement = true;
            }
            else{
                currentNode = currentNode.getNextNode();
            }
        }
        if (!containsElement)
            throw new ArrayIndexOutOfBoundsException("Element not Found");
        else {
            Object t = removeNode(currentNode);
            return t;
        }
    }

    public Object removeNode(Node node){

        Object t = node.getCurrentObject();
        if (node == firstNode) {
            t = removeFirst();
        }
        else if (node == lastNode) {
            t = removeLast();
        }
        else {
            link2Nodes(node.getPreviousNode(), node.getNextNode());
            node.delete();
            size--;
        }
        return t;
    }

    @Override
    public Object removeFirst() {
        Node node = firstNode;
        Object t = node.getCurrentObject();
        firstNode = node.getNextNode();
        node.getNextNode().setPreviousNode(null);
        node.delete();
        size--;
        return t;
    }

    @Override
    public Object removeLast() {
        Node node = lastNode;
        Object t = node.getCurrentObject();
        lastNode = node.getPreviousNode();
        node.getPreviousNode().setNextNode(null);
        node.delete();
        size--;
        return t;
    }

    @Override
    public List toJavaList() {
        List<Object> l = new ArrayList<Object>();
        Node currentNode = firstNode;
        while(currentNode != null){
            l.add(currentNode.getCurrentObject());
            currentNode = currentNode.getNextNode();
        }
        return l;
    }

    public void initialNode(Object newData){
        firstNode = new Node(newData,  null, null);
        lastNode = firstNode;
        size++;
    }

    public void link2Nodes(Node formerNode, Node latterNode){
        formerNode.setNextNode(latterNode);
        latterNode.setPreviousNode(formerNode);
    }

    @Override
    public String toString(){
        Node currentNode = firstNode;
        String s = "[";
        while(currentNode != null){
            if(currentNode.getNextNode() == null){
                s += currentNode.getCurrentObject();
            }
            else {
                s += currentNode.getCurrentObject() + ", ";
            }
            currentNode = currentNode.getNextNode();
        }
        s += "]";
        return s;
    }

    @Override
    public void addBefore(Object searchElement, Object newData) {
        Node currentNode = firstNode;
        Boolean eFound = false;
        while (currentNode != null && !eFound){
            if(currentNode.getCurrentObject() == searchElement){
                eFound = true;
            }
            else{
                currentNode = currentNode.getNextNode();
            }
        }
        if(currentNode == null){
            throw nodeNotFound();
        }
        else {
            Node newNode = new Node(newData, currentNode, currentNode.getPreviousNode());
            currentNode.getPreviousNode().setNextNode(newNode);
            currentNode.setPreviousNode(newNode);
            size++;
        }
    }

    @Override
    public void addAfter(Object searchElement, Object newData) {
        Node currentNode = firstNode;
        Boolean eFound = false;
        while (currentNode != null && !eFound){
            if(currentNode.getCurrentObject() == searchElement){
                eFound = true;
            }
            else{
                currentNode = currentNode.getNextNode();
            }
        }
        if(currentNode == null){
            throw nodeNotFound();
        }
        else {
            Node newNode = new Node(newData, currentNode.getNextNode(), currentNode);
            currentNode.getNextNode().setPreviousNode(newNode);
            currentNode.setNextNode(newNode);
            size++;
        }
    }

    @Override
    public void replace(Object oldData, Object newData) {
        Node currentNode = firstNode;
        Boolean eFound = false;
        while (currentNode != null && !eFound){
            if(currentNode.getCurrentObject() == oldData){
                eFound = true;
            }
            else{
                currentNode = currentNode.getNextNode();
            }
        }
        if(currentNode == null){
            throw nodeNotFound();
        }
        else{
            currentNode.setCurrentObject(newData);
        }
    }

    @Override
    public void insert(int index, Object newData) {
        Node currentNode = firstNode;
        if (index <= size) {
            for (int i = 0; i < index; i++) {
                currentNode = currentNode.getNextNode();
            }
        }
        else {
            System.out.println("Index out of Bounds");
        }
        Node newNode = new Node(newData, currentNode, currentNode.getPreviousNode());
        currentNode.getPreviousNode().setNextNode(newNode);
        currentNode.setPreviousNode(newNode);
        size++;
    }

    @Override
    public Object removeIndex(int index) {
        Node currentNode = firstNode;
        for (int i = 0; i < index; i++){
            currentNode = currentNode.getNextNode();
        }
        return removeNode(currentNode);
    }

    private static RuntimeException nodeNotFound(){
        return new RuntimeException("Node not found.");
    }
}
