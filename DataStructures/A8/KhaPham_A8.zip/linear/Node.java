package linear;

public class Node {
    private Object currentObject;
    private Node nextNode;
    private Node previousNode;

    public Node(Object currentObject, Node nextNode, Node previousNode){
        this.currentObject = currentObject;
        this.nextNode = nextNode;
        this.previousNode = previousNode;
    }

    public Object getCurrentObject() {
        return currentObject;
    }

    public void setCurrentObject(Object currentObject) {
        this.currentObject = currentObject;
    }

    public Node getNextNode() {
        return nextNode;
    }

    public void setNextNode(Node nextNode) {
        this.nextNode = nextNode;
    }

    public Node getPreviousNode() {
        return previousNode;
    }

    public void setPreviousNode(Node previousNode) {
        this.previousNode = previousNode;
    }

    public void delete(){
        setNextNode(null);
        setPreviousNode(null);
        setCurrentObject(null);
    }
}
